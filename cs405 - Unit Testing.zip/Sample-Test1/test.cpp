// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // First empty the collection:
    collection->empty();

    // Then add the entries
    add_entries(5);

    // Then verify the number of entries is 5
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeTest) {
    // First empty the collection
    collection->empty();

    // Check max vs size for 0 entries:
    ASSERT_GT(collection->max_size(), collection->size());

    // Then start in on the tests for 1, 5, and 10
    add_entries(1);  // Now 1 entry in the collection

    ASSERT_GT(collection->max_size(), collection->size());

    add_entries(4); // Bring the entries to 5
    ASSERT_GT(collection->max_size(), collection->size());

    add_entries(5); // Bring the entries to 10
    ASSERT_GT(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityTest) {
    // Check for 0 entries:
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 1
    add_entries(1);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 4
    add_entries(4);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 5
    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());

}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, TestResizingIncrease) {
    // Initial size of collection:
    int initialSize = collection->capacity();

    // Resize the collection
    collection->resize(100);

    // Verify the capacity is greater than as at the start:
    ASSERT_GT(collection->capacity(), initialSize);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, TestResizingDecrease) {
    // Resize collection to bring it up
    collection->resize(100);
    int initialState = collection->capacity();

    // Resize down
    collection->resize(50);
    ASSERT_LT(collection->capacity(), initialState);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, TestResizeDecreaseToZero) {
    // Resize collection to bring it up.
    collection->resize(40);
    // Bring collection to zero.
    collection->resize(0);

    ASSERT_EQ(collection->capacity(), 0);
}


// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, TestClearCollection) {
    // Add something to the collection
    add_entries(5);

    // Clear collection
    collection->clear();

    // Validate the collection is now empty
    ASSERT_TRUE(collection->empty());
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, TestEraseBeginEnd) {
    // Add something to the collection
    add_entries(5);

    // Erase collection
    ASSERT_NO_THROW("collection->erase(begin, end)");
    ASSERT_TRUE(collection->empty());

}
// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, TestReserve) {
    // Get the initial size of the collection:
    int size = collection->size();
    int capacity = collection->size();

    // Execute reserve on the collection:
    collection->reserve(20);
    ASSERT_EQ(collection->size(), size);
    ASSERT_LT(capacity, collection->capacity());

}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, TestOutOfRangeException) {
    // Add 5 entries to the collection
    add_entries(5);

    // Attempt to access element 10 in the collection
    ASSERT_NO_THROW(collection->at(10));
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// Positive test:  Test that the collection can be expanded to 100 elements
TEST_F(CollectionTest, Test100Elements) {
    // Add 100 elements to the collection
    add_entries(100);

    // Validate that the size of the collection is 100 elements.
    ASSERT_EQ(collection->size(), 100);
}

// Negative test: Validate that -1 can be set as the capacity of the collection
TEST_F(CollectionTest, TestNegativeCapacity) {
    ASSERT_NO_THROW(collection->resize(-1));
}